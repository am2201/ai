add() :-
    write("Enter the first number : "),
    read(X),
    write("Enter the second number : "),
    read(Y),
    Z is X+Y,
    write("Sum = "), write(Z).
